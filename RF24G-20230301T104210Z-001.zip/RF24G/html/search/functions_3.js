var searchData=
[
  ['setaddress',['setAddress',['../classpacket.html#adc07da444b32a9105a211862e5b7f6c3',1,'packet']]],
  ['setchannel',['setChannel',['../class_r_f24___g.html#a84472b6c06d38d0e04d783056d1b2698',1,'RF24_G']]],
  ['setcnt',['setCnt',['../classpacket.html#a583358f8d3e3361ba62af95ecd0308c2',1,'packet']]]
];
