var searchData=
[
  ['write',['write',['../class_r_f24___g.html#ac10bdf625f27df73183788a6358d2e71',1,'RF24_G']]]
];
