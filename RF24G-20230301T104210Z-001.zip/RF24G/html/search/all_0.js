var searchData=
[
  ['addpayload',['addPayload',['../classpacket.html#af40fdcda00a1371c60e9e4444df0c13f',1,'packet']]],
  ['available',['available',['../class_r_f24___g.html#a7298349aea33bf12acdf242b7527302b',1,'RF24_G']]],
  ['a_20simple_20interface_20for_20the_20rf24_20radio_20that_20abstracts_20thmr20_27s_20driver_2e',['A simple interface for the RF24 radio that abstracts thmr20&apos;s driver.',['../index.html',1,'']]]
];
