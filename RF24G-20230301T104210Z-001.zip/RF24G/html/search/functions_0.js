var searchData=
[
  ['addpayload',['addPayload',['../classpacket.html#af40fdcda00a1371c60e9e4444df0c13f',1,'packet']]],
  ['available',['available',['../class_r_f24___g.html#a7298349aea33bf12acdf242b7527302b',1,'RF24_G']]]
];
