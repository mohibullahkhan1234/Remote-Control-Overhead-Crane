var searchData=
[
  ['a_20simple_20interface_20for_20the_20rf24_20radio_20that_20abstracts_20thmr20_27s_20driver_2e',['A simple interface for the RF24 radio that abstracts thmr20&apos;s driver.',['../index.html',1,'']]]
];
