# RF24G
This library provides a simple way for up to 6 nRF24L01 radios to communicate with each other.
